
 var https = require('https'),
 fs = require('fs'),
 connect = require('connect'),
 UAParser = require('./ua-parser'),
 //lame = require('lame'),
 watson = require('watson-developer-cloud'),
 SpeakerStream = require('./speaker-stream'),
 WebSocket = require('websocket').w3cwebsocket,
 Url = require('url'),
 portfinder = require('portfinder'),
 utterance = require('./utterance').Utterance;
const speech_to_text = new watson.SpeechToTextV1({
    "url": "https://stream.watsonplatform.net/speech-to-text/api",
    "username": "85228eb7-fcf6-4a8b-852b-dbacd73904ae",
    "password": "SvwquH2lrF4s"
});
const speech_to_text2 = new watson.SpeechToTextV1({
"url": "https://stream.watsonplatform.net/speech-to-text/api",
"username": "85228eb7-fcf6-4a8b-852b-dbacd73904ae",
"password": "SvwquH2lrF4s"
});

var stt_params = {
    continuous: true,
    content_type: "audio/l16;rate=16000",
    speaker_labels: true,
    objectMode: true,
    action: "start",
    interim_results: false,
    profanity_filter: false,
    word_alternatives_threshold: 0.2,
    keywords: keywords,
    keywords_threshold: 0.2,
    inactivity_timeout: 5
};
var stt_params2 = {
    continuous: true,
    content_type: "audio/l16;rate=16000",
    //speaker_labels: true,
    word_alternatives_threshold: 0.2,
    objectMode: true,
    action: "start",
    interim_results: true,
    profanity_filter: false,
    inactivity_timeout: 5
};

class watsonSpeech {
    constructor(username, pw, content_type) {
        var self = this;
        self.stt_interim = new watson.SpeechToTextV1({
            "url": "https://stream.watsonplatform.net/speech-to-text/api",
            "username": username,
            "password": pw
        });
        self.stt_speakerLabels = new watson.SpeechToTextV1({
            "url": "https://stream.watsonplatform.net/speech-to-text/api",
            "username": username,
            "password": pw
        });
        self.interim_params = {
            continuous: true,
            content_type: content_type,
            //speaker_labels: true,
            word_alternatives_threshold: 0.2,
            objectMode: true,
            action: "start",
            interim_results: true,
            profanity_filter: false,
            inactivity_timeout: 5
        };
        self.speakerLabels_params = {
            continuous: true,
            content_type: content_type,
            speaker_labels: true,
            objectMode: true,
            action: "start",
            interim_results: false,
            profanity_filter: false,
            word_alternatives_threshold: 0.2,
            keywords: keywords,
            keywords_threshold: 0.2,
            inactivity_timeout: 5
        }
        self.recognizeStream = null;
        self.recognizeStreamInterim = null;
        self.utterenceCount = 0;
        self.sessionWriteStream = "";
        self.writeStream = "";
    }
    setUpStreams() {
        var self = this;

    }
}

util.inherits(watsonSpeech, EventEmitter);
module.exports = watsonSpeech;